<?php
require_once "Cv/Cv.php";
class Data extends Cv {
    public $judul="C | M";
    public $nama ="RAITA RAHMATINA";
    public $pekerjaan="----------------------- Graphic Desaigner -----------------------";
    public $telpon ="087820195180";
    Public $alamat ="Jl. Adonis Samad";
    public $email ="raita221201@gmail.com";

    public function getIsiCv(){
        $str = parent::data();
        return $str;
        }
}