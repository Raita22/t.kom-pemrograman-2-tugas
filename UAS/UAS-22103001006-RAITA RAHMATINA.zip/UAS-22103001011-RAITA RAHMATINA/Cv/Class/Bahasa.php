<?php
require_once "Cv/Cv.php";
class Bahasa extends Cv {
    public $box4="BAHASA";
    public $bahasa1="Indonesia";
    public $bahasa2="English";

    public function getIsiCv(){
        $str = parent::indo();
        return $str;
        }
        public function eng(){
            return "* * * * * *"; 
        }
}