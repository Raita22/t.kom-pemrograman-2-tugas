<?php
require_once "Cv/Cv.php";
class Pendidikan extends Cv {
    public $box2="PENDIDIKAN";
    public $sklh1="SMKN 4 Palangka Raya <br> 2016-2019";
    public $sklh2="IAIN Palangka Raya <br> 2019-2023";

    public function getIsiCv(){
        $str = "-" . parent::ketSklh1() . "-" ;
        return $str;
        }

    public function ketSklh2(){
        return "Komunikasi Penyiaran";
    }
}