<?php
require_once "Cv/Cv.php";
class Keahlian extends Cv {
    public $box3="KEAHLIAN";
    public $ahli1="Communication";
    public $ahli2="Design";
    public $ahli3="Problem Solving";

    public function getIsiCv(){
        $str = "-" . parent::ketBisa1() . "-" ;
        return $str;
        }
        public function ketBisa2(){
            return "* * * * * * * * *"; 
        }
        public function ketBisa3(){
            return "* * * * * * * *"; 
        }
}
