<?php
require_once "Cv/Cv.php";
class Pengalaman extends Cv {
    public $box1="PENGALAMAN";
    public $p1="Freelancer.co.id <br> 2018";
    public $p2="Freelancer.co.id  <br>2021";
    public $p3="Freelancer.co.id  <br> 2023"; 

    public function getIsiCv(){
        $str = "-" . parent::KetP1() . "-" ;
        return $str;
        }
        public function ketP2(){
            return "Photographer"; 
        }
        public function ketP3(){
            return "Jurnalis"; 
        }
}