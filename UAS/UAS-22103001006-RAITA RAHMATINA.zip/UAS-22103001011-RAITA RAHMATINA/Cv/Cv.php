<?php

 abstract class Cv{

    abstract function getIsiCv();

    public function data(){
        return "Nama saya Raita Rahmatina lulusan perguruan tunggi
        IAIN palangkaraya. Saya seorang ahli dibidang Graphic Desaigner selama 5 tahaun. 
        Saya akan bekerja dengan jujur dan disiplin serta saya juga dapat bekerja dengan tim. "; 
    }
    // box pendidikan 
    public function ketSklh1(){
        return "Multimedia";
    }
    // box Bahasa
    public function indo(){
        return "* * * * * * *"; 
    }
    // box pengalaman
    public function ketP1(){
        return "Design Invitation Card, Logo"; 
    }
    //box bisa 
    public function ketBisa1(){
        return "* * * * * * * * *"; 
    }
}