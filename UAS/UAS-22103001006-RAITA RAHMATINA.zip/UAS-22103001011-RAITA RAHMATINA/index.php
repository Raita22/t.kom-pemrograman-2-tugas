<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/syle.css">
</head>
<body>
    <div class="kotak1">
        <h2><?php require_once "Cv/Class/Data.php";
            $isi = new Data();
            echo $isi->judul;?></h2>
    <h1><?php require_once "Cv/Class/Data.php";
            $isi = new Data();
            echo $isi->nama;?></h1>
            <h2><?php require_once "Cv/Class/Data.php";
            $isi = new Data();
            echo $isi->pekerjaan;?></h2>

            <div class="a">
                <img src="Gambar/619.png">
            <tr><?php require_once "Cv/Class/Data.php";
            $isi = new Data();
            echo $isi->alamat;?></tr></div>

            <div class="b">
            <img src="Gambar/00.png">
            <tr><?php require_once "Cv/Class/Data.php";
            $isi = new Data();
            echo $isi->telpon;?></tr></div>

             <div class="c">
             <img src="Gambar/76.png">
            <tr><?php require_once "Cv/Class/Data.php";
            $isi = new Data();
            echo $isi->email;?></tr></div>

    </div>

<div class="data">

</div>

<div class="kiri">
<img class="foto" src="Gambar/22.jpg">
    <div class="kotak2">
<h3><?php require_once "Cv/Class/Pendidikan.php";
            $isi = new Pendidikan();
            echo $isi->box2;?></h3>
<ul>
    <li><?php require_once "Cv/Class/Pendidikan.php";
            $isi = new Pendidikan();
            echo $isi->sklh1; 
            ?></li> 
            <?php echo $isi->ketSklh1(); ?>
</ul>

<ul>
    <li><?php require_once "Cv/Class/Pendidikan.php";
            $isi = new Pendidikan();
            echo $isi->sklh2; 
            ?></li> 
            <?php echo $isi->ketSklh2(); ?>
</ul>
    </div>

    <div class="kotak3">
<h3><?php require_once "Cv/Class/Bahasa.php";
            $isi = new Bahasa();
            echo $isi->box4;?></h3>
<ul>
    <li><?php require_once "Cv/Class/Bahasa.php";
            $isi = new Bahasa();
            echo $isi->bahasa1;?></li>
                        <?php echo $isi->indo();?>
</ul>
<ul>
    <li><?php require_once "Cv/Class/Bahasa.php";
            $isi = new Bahasa();
            echo $isi->bahasa2;?></li>
            <?php echo $isi->eng();?>
</ul>
    </div>
</div>

<div class="kanan">
    <div class="kotak4">
        <p><?php require_once "Cv/Class/Data.php";
            $isi = new Data();
            echo $isi->data();?> </p>
<h3><?php require_once "Cv/Class/Pengalaman.php";
            $isi = new Pengalaman();
            echo $isi->box1;?></h3>
<ul>
    <li><?php require_once "Cv/Class/Pengalaman.php";
            $isi = new Pengalaman();
            echo $isi->p1;?></li>
            <?php echo $isi->ketP1();?>
</ul>
<ul>
    <li><?php require_once "Cv/Class/Pengalaman.php";
            $isi = new Pengalaman();
            echo $isi->p2;?></li>
            <?php echo $isi->ketP2();?>
</ul>
<ul>
    <li><?php require_once "Cv/Class/Pengalaman.php";
            $isi = new Pengalaman();
            echo $isi->p3;?></li>
            <?php echo $isi->ketP3();?>
</ul>
    </div>

    <div class="kotak5">
<h3><?php require_once "Cv/Class/Keahlian.php";
            $isi = new Keahlian();
            echo $isi->box3;?></h3>
<ul>
<li><?php require_once "Cv/Class/Keahlian.php";
            $isi = new Keahlian();
            echo $isi->ahli1;?></li>
            <?php echo $isi->ketBisa1();?>
</ul>
<ul>
<li><?php require_once "Cv/Class/Keahlian.php";
            $isi = new Keahlian();
            echo $isi->ahli2;?></li>
            <?php echo $isi->ketBisa2();?>
</ul>
<ul>
<li><?php require_once "Cv/Class/Keahlian.php";
            $isi = new Keahlian();
            echo $isi->ahli3;?></li>
            <?php echo $isi->ketBisa3();?>
</ul>
    </div>
 </div>
</body>
</html>