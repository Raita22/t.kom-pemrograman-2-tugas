<?php
require_once "Blog/Blog.php";
$titel1 = new Blog();
$paragrap1 = new Blog();
$a = new Blog();
$titel2 = new Blog();
$tg = new Blog();
$lk = new Blog();
$jk = new Blog();
$jk = new Blog();
$jk = new Blog();
$jk = new Blog();
$jk = new Blog();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Library</title>
    <link rel="stylesheet" href="bsCss\bootstrap.min.css">
</head>
<body>
<div class="p-3 mb-2 bg-dark text-white">
  <ul>
    <h1 class="fw-bold fst-italic">
        <?php 
        echo $titel1->title;
        ?>
    </h1>    
    <p class="fw-light">
        <?php 
        echo $paragrap1->paragraph1();
        ?>
    </p>
    <a class="text-reset" href="/">
            <?php 
            echo $a->link();?>
    </a>
  </ul>
</div>
<ol>
    <h1 class="fw-bold">
        <?php 
        echo $titel2->title2; ?>
    </h1>
        <?php 
        echo $tg->date; ?>
    <a href="/">
        <?php 
        echo $lk->time(); ?>
    </a>
    <br>
    <br/>
    <p >
        <?php 
        echo $jk->information1(); ?>
    </p>

    <p class="lh-sm">
        <?php 
        echo $jk->information2(); 
        echo $jk->besar(); 
        echo $jk->info(); ?>
    </p>
    <p class="lh-sm">
        <?php 
        echo $jk->info3(); ?>
    </p>
</ol>
</body>
</html>

